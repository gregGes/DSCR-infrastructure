#!/usr/bin/python
from Interaction import Updating

Updating().update_containers()

Updating().update_memory()
Updating().update_availability()
